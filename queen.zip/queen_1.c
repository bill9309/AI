#include <stdio.h>
#include <stdlib.h>
int block_x(int);
int block_y(int);
struct unique_solutions{
 int first_queen_x;
 int first_queen_y;
 int second_queen_x;
 int second_queen_y;
 int third_queen_x;
 int third_queen_y;
 struct unique_solutions * next;
};
int can_be_attackted(int i,int j);
int is_valid;
int board[6][6];
int a,b,c,d,e,f;
void clear_board();
void print_board();
int answer_already_found(struct unique_solutions *);
int main(){
  clear_board(board);
  int i,j,k;
  //int first,second,third;
  int number_of_possible_solutions = 7140;
  int possible_solutions[number_of_possible_solutions][3];
  int l = 0;
  struct unique_solutions * first;
  first = NULL;

  for(i = 0;i <= 33; i++){
    for(j = i+1; j <= 34; j++){
      for(k = j+1; k<= 35;k++){
        possible_solutions[l][0] = i;
        possible_solutions[l][1] = j;
        possible_solutions[l][2] = k;
        l++;
      }
    }
  }
  for(l = 0; l <= 7139; l++){
    is_valid = 1;
    board[block_x(possible_solutions[l][0])][block_y(possible_solutions[l][0])] = 1;
    board[block_x(possible_solutions[l][1])][block_y(possible_solutions[l][1])] = 1;
    board[block_x(possible_solutions[l][2])][block_y(possible_solutions[l][2])] = 1;
    for(i = 0; i < 6; i++){
      for(j = 0; j < 6; j++){
        if(can_be_attackted(i,j) == 0){
          is_valid = 0;
          break;
        }
      }
      if(is_valid == 0){
        break;
      }
    }

    if(is_valid){
      //printf("%d %d %d\n",possible_solutions[l][0],possible_solutions[l][1],possible_solutions[l][2]);
      /*for(i = 0; i <= 5;i++){
        for(j = 0; j <= 5; j++){
          if(board[i][j] == 1){
            printf("O");
          }
          else{
            printf("X");
          }
        }
        printf("\n");
      }
      printf("---------------\n");*/
    if(first == NULL){
      first = (struct unique_solutions*)malloc(sizeof(struct unique_solutions));
      first -> first_queen_x = block_x(possible_solutions[l][0]);
      first -> first_queen_y = block_y(possible_solutions[l][0]);
      first -> second_queen_x = block_x(possible_solutions[l][1]);
      first -> second_queen_y = block_y(possible_solutions[l][1]);
      first -> third_queen_x = block_x(possible_solutions[l][2]);
      first -> third_queen_y = block_y(possible_solutions[l][2]);
      first -> next = NULL;
      print_board();
    }
    else{
      struct unique_solutions * search;
      int is_unique_answer = 1;
      search = first;
      while(search -> next != NULL){
        if(answer_already_found(search)){
          is_unique_answer = 0;
          break;
        }
        search = search -> next;
      }
      if(answer_already_found(search)){
        is_unique_answer = 0;
      }
      if(is_unique_answer == 1){
        print_board();
        search -> next = (struct unique_solutions*)malloc(sizeof(struct unique_solutions));
        search = search -> next;
        search -> first_queen_x = block_x(possible_solutions[l][0]);
        search -> first_queen_y = block_y(possible_solutions[l][0]);
        search -> second_queen_x = block_x(possible_solutions[l][1]);
        search -> second_queen_y = block_y(possible_solutions[l][1]);
        search-> third_queen_x = block_x(possible_solutions[l][2]);
        search-> third_queen_y = block_y(possible_solutions[l][2]);
        search-> next = NULL;
      }
    }

    }
    clear_board();
  }

}
void print_board(){
  int i,j;
  for(i = 0; i <= 5;i++){
    for(j = 0; j <= 5; j++){
      if(board[i][j] == 1){
        printf("Q");
      }
      else{
        printf("*");
      }
    }
    printf("\n");
  }
  printf("---------------\n");
}
int block_x(int position){
  return position % 6;
}

int block_y(int position){
  return position / 6;
}
void clear_board(){
  int i,j;
  for(i = 0; i < 6;i++){
    for(j = 0; j < 6;j++){
      board[i][j] = 0;
    }
  }
}

int answer_already_found(struct unique_solutions* search){

 int x_1,y_1,x_2,y_2,x_3,y_3;
 //Top-Bottom Symmetry
 x_1 = 5 - search -> first_queen_x;
 y_1 = search -> first_queen_y;
 x_2 = 5 - search -> second_queen_x;
 y_2 = search -> second_queen_y;
 x_3 = 5 - search -> third_queen_x;
 y_3 = search -> third_queen_y;
 if(board[x_1][y_1] == 1 && board[x_2][y_2] == 1 && board[x_3][y_3] == 1){
   return 1;
 }
 //Left-Right Symmetry
 x_1 = search -> first_queen_x;
 y_1 = 5 - search -> first_queen_y;
 x_2 = search -> second_queen_x;
 y_2 = 5 - search -> second_queen_y;
 x_3 = search -> third_queen_x;
 y_3 = 5 - search -> third_queen_y;
 if(board[x_1][y_1] == 1 && board[x_2][y_2] == 1 && board[x_3][y_3] == 1){
   return 1;
 }
 //Diaognal Symmetry
 x_1 = search -> first_queen_y;
 y_1 = search -> first_queen_x;
 x_2 = search -> second_queen_y;
 y_2 = search -> second_queen_x;
 x_3 = search -> third_queen_y;
 y_3 = search -> third_queen_x;
 if(board[x_1][y_1] == 1 && board[x_2][y_2] == 1 && board[x_3][y_3] == 1){
   return 1;
 }
 //Diagonal Symmetry
 x_1 = 5 - search -> first_queen_y;
 y_1 = 5 - search -> first_queen_x;
 x_2 = 5 - search -> second_queen_y;
 y_2 = 5 - search -> second_queen_x;
 x_3 = 5 - search -> third_queen_y;
 y_3 = 5 - search -> third_queen_x;

 if(board[x_1][y_1] == 1 && board[x_2][y_2] == 1 && board[x_3][y_3] == 1){
   return 1;
 }
 //90 Degrees
 x_1 = search -> first_queen_y;
 y_1 = 5 - search -> first_queen_x;
 x_2 = search -> second_queen_y;
 y_2 = 5 - search -> second_queen_x;
 x_3 = search -> third_queen_y;
 y_3 = 5 - search -> third_queen_y;
 if(board[x_1][y_1] == 1 && board[x_2][y_2] == 1 && board[x_3][y_3] == 1){
   return 1;
 }
 //180 Degrees
 x_1 = 5 - search -> first_queen_x;
 y_1 = 5 - search -> first_queen_y;
 x_2 = 5 - search -> second_queen_x;
 y_2 = 5 - search -> second_queen_y;
 x_3 = 5 - search -> third_queen_x;
 y_3 = 5 - search -> third_queen_y;
 if(board[x_1][y_1] == 1 && board[x_2][y_2] == 1 && board[x_3][y_3] == 1){
   return 1;
 }
 //270 Degrees
 x_1 = 5 - search -> first_queen_y;
 y_1 = search -> first_queen_x;
 x_2 = 5 - search -> second_queen_y;
 y_2 = search -> second_queen_x;
 x_3 = 5 - search -> third_queen_y;
 y_3 = search -> third_queen_x;
 if(board[x_1][y_1] == 1 && board[x_2][y_2] == 1 && board[x_3][y_3] == 1){
   return 1;
 }
 return 0;

}

int can_be_attackted(int i,int j){
  int k;
  int a;
  for(k = 0; k <= 5; k++){
    if(board[i][k] || board[k][j]){
      return 1;
    }
  }
  for(a = 0 ; a<= 5; a++){
    if( i-a >= 0 && j-a >= 0 ){
      if(board[i-a][j-a]== 1){
      return 1;
    }
  }
  if(i+a <= 5 && j+a <= 5){
    if(board[i+a][j+a] == 1){
      return 1;
    }
  }
  if(i-a >= 0 && j+a <= 5){
    if(board[i-a][j+a] == 1){
      return 1;
    }
  }
  if(i+a <= 5 && j-a >= 0){
    if(board[i+a][j-a] == 1){
      return 1;
    }
  }
  }
    return 0;
}
